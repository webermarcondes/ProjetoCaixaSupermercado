import java.time.LocalDate;

public class Venda {

    private Integer codigoVenda;
    private LocalDate dataVenda;
    private Desconto desconto;

}
