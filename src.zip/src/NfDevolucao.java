public class NfDevolucao {
}
